import{b as o}from"./core-Do3_DFoK.js";import"./index-DRhqSGA3.js";import"./events-CPRKoTpB.js";import"./index.es-4EKSIvHv.js";import"./index-nibyPLVP.js";const p=o`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M2.54 2.54a1 1 0 0 1 1.42 0L8 6.6l4.04-4.05a1 1 0 1 1 1.42 1.42L9.4 8l4.05 4.04a1 1 0 0 1-1.42 1.42L8 9.4l-4.04 4.05a1 1 0 0 1-1.42-1.42L6.6 8 2.54 3.96a1 1 0 0 1 0-1.42Z"
    clip-rule="evenodd"
  />
</svg>`;export{p as closeSvg};
